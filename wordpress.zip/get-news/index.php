<?php
/**
 *连接数据库并取出最新的记录条数
 * @return array
 */
    function grubnews($res=11){
    $link = mysql_connect('localhost','root','root',true);
    if(!$link){
        echo '无法连接数据库:'.mysql_error();
        exit;
    }
    if(!mysql_select_db('wordpress',$link)){
        echo '无法选择数据库'.mysql_error();
    };
        $contents=array();
        if(!file_exists(dirname(__FILE__).'/final_id.txt')){
            $sql = "select * from wp_posts ORDER by ID DESC LIMIT ".$res;
            $result = mysql_query($sql);
            while($row = mysql_fetch_row($result)){
                $contents[]=$row;
            }
            if(!empty($contents)){
                file_put_contents(dirname(__FILE__).'/final_id.txt',$contents[0][0]);
            }
        }else{
            $front_id=file_get_contents(dirname(__FILE__).'/final_id.txt');
            $sql = 'select * from wp_posts WHERE `ID`>'.$front_id.' ORDER by `ID` DESC LIMIT '.$res; //查询SQL
            if($result = mysql_query($sql)){
              while($row = mysql_fetch_row($result)){
               $contents[]=$row;
              }
                if(!empty($contents)){
                    file_put_contents(dirname(__FILE__).'/final_id.txt',$contents[0][0]);
                }
           }
        }
        mysql_close($link);
    return $contents;
    }
/**
 * 将含有GBK的中文数组转为utf-8
 *
 * @param array $arr   数组
 * @param string $in_charset 原字符串编码
 * @param string $out_charset 输出的字符串编码
 * @return array
 */
function array_iconv($arr, $in_charset="gbk", $out_charset="utf-8")
{
    $ret = eval('return '.iconv($in_charset,$out_charset,var_export($arr,true).';'));
    return json_encode($ret);
}
echo array_iconv(grubnews());



